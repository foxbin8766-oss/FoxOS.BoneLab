FOX OS WebXR Prototype 0.1
This is a PC-free visual/interaction prototype, not a BONELAB pallet.
It uses temporary procedural geometry so the final FOX models can be swapped in later.

Run:
1. Host index.html on an HTTPS web host.
2. Open the HTTPS page in the Quest browser.
3. Press ENTER VR.
4. Explore the temporary facility.

WebXR immersive VR requires a compatible browser/device and a trustworthy (HTTPS) context.
